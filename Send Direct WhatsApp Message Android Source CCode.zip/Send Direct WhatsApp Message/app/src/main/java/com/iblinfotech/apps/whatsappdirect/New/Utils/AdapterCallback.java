package com.iblinfotech.apps.whatsappdirect.New.Utils;

/**
 * Created by iblinfotech on 13/09/18.
 */

public interface AdapterCallback {

    public void onPositionClicked(String phoneNUmber);

}
